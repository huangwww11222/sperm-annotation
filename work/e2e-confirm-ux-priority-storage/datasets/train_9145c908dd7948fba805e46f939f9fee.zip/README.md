# 已完成审查与对比确认的训练数据集

图片来自原始视频；标签仅来自导出清单中的最终版本，未修改对象沿用 A，空帧保留空标签。
YOLO 标签为 class_id cx cy w h，坐标按实际图像尺寸归一化，类别编号从 0 开始。
解压整个 ZIP 后，向 YOLO 传入本目录下 data.yaml 的绝对路径；无需访问导出服务器的目录。
例如：`yolo detect train model=yolov8n.pt data=/绝对路径/数据集/data.yaml epochs=100`
纯 COCO 导出使用 annotations/instances_train.json 和 instances_val.json，图片路径相对该 JSON 文件。

训练/验证按确定的帧序划分；必要时交换一帧，保证训练集包含目标，且有至少两张正样本时验证集也包含目标。两部分没有重复图片。
同一视频内的帧相关性较高；需要独立视频评估时，请在训练前按采集批次重新组织验证集。
manifest.json 记录实际划分、原视频摘要与最终版本。provenance/ 保留完整 A/B/最终框用于追溯。
